//
//  main.cpp
//  Sort
//
//  Created by Sathya Babu on 08/02/24.
//

#include <iostream>
#include <string_view>
#include<functional>
#include<array>
#include<algorithm>
using namespace std;


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
std:array<int,10> s = { 5,7,4,2,8,6,1,9,0,3} ;
    auto print = [ &s ]( std::string_view const rem){
        for( auto a : s ){
            cout << a << " " ;
        }
        cout << " : " << rem << endl;
    };
    std::sort(s.begin(),s.end());
    print("Sorted with default operator < ");
    
    std::sort(s.begin(),s.end(),std::greater<int>()  );
    print("Sorted with The greater api ");
    
    struct{
        bool operator()( int a , int b) const { return a < b; }
        
    }customLess ;
    std::sort(s.begin(),s.end(),customLess  );
    print("Sorted with customLess struct.. ");
    
    std::sort(s.begin(),s.end(),[]( int a, int b){
        return a > b ;
    });
    print("Sorted with my lambda.... ");
    
    
    return 0;
}
