//
//  main.cpp
//  LambdaCallback
//
//  Created by Sathya Babu on 08/02/24.
//

#include <iostream>
using namespace std;
//std::function<void(int)> fun ;
void callwithNumber( void( *bar)(int)){
    bar(10);
}
int main(int argc, const char * argv[]) {
    struct {
        using f_ptr = void(*)(int);
        void operator()( int s ) const { return call( s );}
        operator f_ptr() const { return& call; }
        
        private :
        static void call( int s ) { cout << s << endl;};
        
    }baz ;
    callwithNumber( baz );
    callwithNumber( [](int x ){ cout << x << endl;});
    return 0;
}
