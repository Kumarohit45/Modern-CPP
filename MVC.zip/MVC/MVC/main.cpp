//
//  main.cpp
//  MVC
//
//  Created by Sathya Babu on 08/02/24.
//

#include <iostream>
using namespace std ;

class CounterModel{
    
    private :
    int count ;
    public :
    CounterModel() : count( 0 ){};
    
     int getCount() const {
        return count ;
        }
    void increment(){
        count++;
    }
    
};
class CounterView {
    public :
    void displayCount(int count ) const {
        cout << " Count : " << count << endl;
    }
};

class CounterControler{
    private :
    CounterModel& model ;
    CounterView& view ;
    public :
    CounterControler( CounterModel& model, CounterView& view) : model( model), view(view){}
    
    void incrementCounter(){
        model.increment();
        updateViews();
    }
    void updateViews() const {
        view.displayCount( model.getCount());
    }
};
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "MVC framework!\n";
    CounterModel model ;
    CounterView  view ;
    CounterControler controller(model, view);
    // Initial display
    controller.updateViews();
    controller.incrementCounter();
    controller.incrementCounter();
    controller.incrementCounter();
   // controller.updateViews();
    return 0;
}
