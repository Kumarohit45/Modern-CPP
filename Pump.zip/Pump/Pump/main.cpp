//
//  main.cpp
//  Pump
//
//  Created by Sathya Babu on 06/02/24.
//

#include <iostream>
#include<stdexcept>
using namespace std ;

template< int fuel>

float pump( int additionalOil ) requires( fuel >= 10 )
{
    //constexpr
    int minFuel = 10.0f ;
    if( fuel + additionalOil < minFuel ){
        throw std::runtime_error("Car would stop any min!!");
    }
    return fuel + additionalOil;
}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    try{
        cout << " Pump : " <<  pump<38>(20) << endl;
    } catch ( const  std::runtime_error& e){
        cout << " Exception : " << e.what() << endl ;
    }
    cout << " End of the code " << endl;
    return 0;
}
