//
//  main.cpp
//  Lambda_Mutable
//
//  Created by Sathya Babu on 07/02/24.
//

#include <iostream>
using namespace std ;



int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Mutable!\n";
    
    int i = 90 ;
    int ammo{ 10 };
    auto shoot{
        
        [ ammo ] () mutable {
            cout << __PRETTY_FUNCTION__ << endl;
            --ammo ;
            cout << " Pew! "<< ammo << " Shot's left" << endl;
        }
        
        
    };
    shoot();
    shoot();
    return 0;
}
