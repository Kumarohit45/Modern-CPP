//
//  main.cpp
//  Shared_ptr_BUGS
//
//  Created by Sathya Babu on 15/02/24.
//
#include <iostream>
#include <memory>
class A; class B;
class A {
 public:  std::shared_ptr< B > pointer;
   
    A() {
        std::cout << "A was Constructed" << std::endl;
    }
    ~A() {
        std::cout << "A was destroyed" << std::endl;
    }
};

 class B {
      public :    std::shared_ptr< A > pointer;
   
    B() {
        std::cout << "B was Constructed" << std::endl;
    }
    ~B() {
        std::cout << "B was destroyed" << std::endl;
    }
};
int main() {
    
    std::shared_ptr<A> a = std::make_shared< A >();
    std::shared_ptr<B> b = std::make_shared< B >();
    
    a->pointer = b;     // b is free        :  A was destroyed
   // b->pointer = a;
}
/*
 A was Constructed
 B was Constructed
 A was destroyed
 B was destroyed
 Program ended with exit code: 0
 */
