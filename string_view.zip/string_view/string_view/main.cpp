//
//  main.cpp
//  string_view
//
//  Created by Sathya Babu on 08/02/24.
//

#include <iostream>
using namespace std;
void printSubString( std::string_view str){
    //str+= "Changed";
    cout << "Sub string : " << str << endl;
}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "string_view!\n";
    std::string str = "Hello world";
    str[ 7 ] = 'x';
    cout << str << endl;
    
    // Phase II
    const char* cStr = "Hello world";
    std::string_view view( cStr,5);// view first 5 chr
//    view[ 0 ] = 'X';
    cout << " std::string_view " << view << endl;
    
    // Phase III
    
    std::string originalString = "Hello World";
    std::string_view subStringView(originalString.c_str() + 7, 5);
    printSubString( subStringView);
    cout << "Original String " << originalString << endl ;
    return 0;
}
