//
//  main.cpp
//  Car_StateMAchine_WithSensors
//
//  Created by Sathya Babu on 16/02/24.
// By Aparna

#include<iostream>

class CarState {
    public:
    virtual void putKey() = 0;
    virtual void accelerate() = 0;
    virtual void brake() = 0;
    virtual void removeKey() = 0;
};

class Fuel {
    float fuel;
    public:
        Fuel() : fuel(90) {};
        Fuel(int f) : fuel(f){};
        float getFuel() {
            return fuel;
        }
        void setFuel(float f) {
            fuel = f;
        }
};

class Oil {
    float oil;
    public:
        Oil() : oil(80) {};
        Oil(int o) : oil(o){};
        float getOil() {
            return oil;
        }
        void setOil(float o) {
            oil = o;
        }

};

class Battery {
    float battery;
    public:
        Battery() : battery(100){};
        Battery(int b) : battery(b) {};
        float getBattery() {
            return battery;
        }
        void setBattery(float b) {
            battery = b;
        }
};


class VController {
    public:
    Fuel f;
    Battery b;
    Oil o;
    VController() = default;
    VController(Fuel f, Battery b, Oil o) :  f(f) , o(o), b(b) {};
    bool checkFuel() {
        if(f.getFuel()<5) {
            return false;
        }
        else {
            f.setFuel(f.getFuel()-5);
            //std::cout<<"Fuel: "<<f.getFuel()<<std::endl;
            return true;
        }
    }

    bool checkOil() {
        if(o.getOil()<1) {
            return false;
        }
        else {
            o.setOil(o.getOil()-3);
            //std::cout<<"Oil: "<<o.getOil()<<std::endl;
            return true;
        }
    }

    bool checkBattery() {
        if(b.getBattery()<2) {
            return false;
        }
        else {
            b.setBattery(b.getBattery()-10);
            //std::cout<<"Battery: "<<b.getBattery()<<std::endl;
            return true;
        }
    }
};

class Car {
    CarState* carstate;
    int carspeed;

    public:
    VController vc; // let the state machine in it do the job of comparing and send an external state as a state to the car.
    /*
     
     void On::accelerate()  {
         // as the folllowing code looks shabby!
         
         if(car->vc.checkFuel() && car->vc.checkBattery() && car->vc.checkOil()) {
             
             car->setCarState(new Drive(car));
             car->setCarSpeed(car->getCarSpeed()+10);
             std::cout<<"Accerelate : The car started moving now. Present car speed: "<<car->getCarSpeed()<<std::endl;
         }
     */

    Car(VController vc);
    void setCarState(CarState* state);
    int getCarSpeed();
    void setCarSpeed(int speed);
    void putKey();
    void accelerate();
    void brake();
    void removeKey();
};

class Off : public CarState {
    Car* car;
    public:
    Off(Car *car) ;
    void putKey() override ;
    void accelerate() override ;
    void brake() override ;
    void removeKey() override;
};


class On : public CarState {
    Car* car;
    public:
    On(Car *car);
    void putKey() override ;
    void accelerate() override ;
    void brake() override ;
    void removeKey() override ;
};

class Drive : public CarState {
    Car* car;
    public:
    Drive(Car *car);
    void putKey() override ;
    void accelerate() override ;
    void brake() override ;
    void removeKey() override ;
};


// Off implemented functions
Off::Off(Car* car) {
    this->car = car;
}

void Off::putKey() {
    if(car->vc.checkFuel() && car->vc.checkBattery() && car->vc.checkOil()) {
            car->setCarState(new On(car));
            std::cout<<"Put key : The car is on now"<<std::endl;
        }
    else {
        std::cout<<"Put key: The car cannot start!!"<<std::endl;
    }
    }


void Off::accelerate()  {
    std::cout<<"Accerelate : Put key first"<<std::endl;
}

void Off::brake() {
    std::cout<<"Brake : Put key first"<<std::endl;
}

void Off::removeKey() {
    std::cout<<"Remove key : Put key first"<<std::endl;
}


// On implemented functions
On::On(Car* car) {
    this->car = car;
}

void On::putKey() {
    std::cout<<"Put key : Key already inserted"<<std::endl;
    }

void On::accelerate()  {
    // as the folllowing code looks shabby!
    
    if(car->vc.checkFuel() && car->vc.checkBattery() && car->vc.checkOil()) {
        
        car->setCarState(new Drive(car));
        car->setCarSpeed(car->getCarSpeed()+10);
        std::cout<<"Accerelate : The car started moving now. Present car speed: "<<car->getCarSpeed()<<std::endl;
    }
    else {
        car->setCarState(new Off(car));
        std::cout<<"Accerelate : The car couldn't accerelate!! Car is off "<<std::endl;
    }
}

void On::brake() {
    std::cout<<"Brake : First start the car"<<std::endl;
}

void On::removeKey() {
    car->setCarState(new Off(car));
    std::cout<<"Remove key : The car is off now"<<std::endl;
}


// Drive implemented functions
Drive::Drive(Car* car) {
    this->car = car;
}

void Drive::putKey() {
    std::cout<<"Put key : Key already inserted"<<std::endl;
}

void Drive::accelerate()  {
    if(car->vc.checkFuel() && car->vc.checkBattery() && car->vc.checkOil()) {
        
        car->setCarSpeed(car->getCarSpeed()+10);
        std::cout<<"Accerelate : The car speed has increased. Present car speed: "<<car->getCarSpeed()<<std::endl;
    }
    else {
        car->setCarState(new On(car));
        car->setCarSpeed(0);
        std::cout<<"Accerelate : The car couldn't accerelate!! Car is stopped "<<std::endl;
    }
}

void Drive::brake() {
    if(car->getCarSpeed()==0) {
        car->setCarState(new On(car));
        std::cout<<"Brake : The car has stopped now!!"<<std::endl;
    }
    else {
        car->setCarSpeed(car->getCarSpeed()-5);
        std::cout<<"Brake : The car speed has decreased. Present car speed: "<<car->getCarSpeed()<<std::endl;
    }
}

void Drive::removeKey() {
    std::cout<<"Remove key : The car is off now"<<std::endl;
    car->setCarState(new Off(car));
}


// Car implementation functions
Car::Car(VController vc) {
    this-> vc = vc;
    carspeed = 0;
    carstate = new Off(this);
}

void Car::setCarSpeed(int s) {
    carspeed = s;
}

int Car::getCarSpeed() {
    return carspeed;
}

void Car::setCarState(CarState* state) {
    if(state!=NULL) {
        carstate = state;
    }
}

void Car::putKey() {
    carstate->putKey();
}

void Car::removeKey() {
    carstate->removeKey();
}

void Car::accelerate() {
    carstate->accelerate();
}

void Car::brake() {
    carstate->brake();
}


int main() {
    
    Fuel    fuel( 40 );
    Battery batttery(100);
    Oil     oil(20);
    
    VController vc(fuel,batttery,oil);

    Car car( vc );

    car.putKey();
    car.accelerate();
    car.accelerate();
    car.brake();
    car.accelerate();
    car.removeKey();

    return 0;
}


