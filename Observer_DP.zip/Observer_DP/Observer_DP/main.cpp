//
//  main.cpp
//  Observer_DP
//
//  Created by Sathya Babu on 22/02/24.
//

#include <iostream>
#include <vector>
using namespace std;
class Observer ;

class Subject{
    public :
    std::vector< Observer* > views ;
    int value ;
    
    void attach( Observer*  obs){
        views.emplace_back( obs );
        }
    void detach( Observer* obs){
        views.erase(std::remove(views.begin(),views.end(),obs),views.end() );
    }
    // State changes.. reg uviews has to be notified..
    void setValue( int val ){
        value = val ;
        notify();
    }
    int getVal(){
        return value;
    }
    void notify();
};

class Observer{
    Subject* model ;
    int denom ;
    
    public :
    Observer( Subject* mod , int div ){
        model = mod;
        denom = div ;
        
        model->attach( this );
    }
    virtual void update() = 0 ;
    
    protected :
    
    Subject* getSubject(){
        return model ;   // this
    }
    int getDivisor(){
        return denom ;
    }
    
};


void Subject::notify(){
    for( int i = 0 ; i < views.size(); i++){
        views[ i ]->update();
    }
}
// Conc observers

class DivObserver: public Observer {
    public :
    DivObserver( Subject* mod, int div) : Observer(mod,div){}
    
    void update() override
    {
        int v = getSubject()->getVal(), d = getDivisor();
        cout << v << " / " << d << " is " << v/d << endl;
    }
};

class AddObserver: public Observer {
    public :
    AddObserver( Subject* mod, int div) : Observer(mod,div){}
    
    void update() override
    {
        int v = getSubject()->getVal(), d = getDivisor();
        cout << v << " + " << d << " is " << v+d << endl;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Observer  \n";
    Subject subj ;
    DivObserver( &subj,  4  );
    DivObserver( &subj,  3  );
    AddObserver( &subj,  12  );
    
    subj.setValue( 14 );
    return 0;
}
