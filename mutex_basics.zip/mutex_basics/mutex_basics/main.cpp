//
//  main.cpp
//  mutex_basics
//
//  Created by Sathya Babu on 19/02/24.
//

#include <iostream>
#include <thread>
#include <mutex>
using namespace std;

int myCash = 0 ;
std::mutex m ;

void addMoney(){
    m.lock();
      ++myCash;
    m.unlock();
}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "mutex \n";
    std::thread t1( addMoney );
    std::thread t2( addMoney );
    
    t1.join();
    t2.join();
    
    return 0;
}
