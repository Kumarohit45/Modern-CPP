//
//  main.cpp
//  CalcComponent
//
//  Created by Sathya Babu on 30/01/24.
//

#include <iostream>
using namespace std ;
// creating an Abstract base class
class Calculator {
  
    public :
    virtual int add( int a , int b ) = 0 ;
    virtual int sub( int a , int b ) = 0 ;
    virtual int mul( int a , int b ) = 0 ;
    virtual int div( int a , int b ) = 0 ;
    
    
};
class BasicCalculator : public Calculator{
    public :
    int add( int a , int b ) override {
        return a + b ;
    }
    int sub( int a , int b ) override {
        return a - b ;
    }
    int mul( int a , int b ) override {
        return a * b ;
    }
    int div( int a , int b ) override {
        return a / b ;
    }
};
class User {
    
    public :
    virtual void requestAdd( Calculator* calc,int a, int b ) = 0 ;
    virtual void requestSub( Calculator* calc,int a, int b ) = 0 ;
    virtual void requestMul( Calculator* calc,int a, int b ) = 0 ;
    virtual void requestDiv( Calculator* calc,int a, int b ) = 0 ;
    
};
class UserSathya : public  User {
    public :
    void requestAdd( Calculator* calc, int a , int b) override {
        cout << " Sum = " << calc->add( a ,b ) << endl;
    }
    void requestSub( Calculator* calc, int a , int b) override{
        cout << " Sub = " << calc->sub( a ,b ) << endl;
    }
    void requestMul( Calculator* calc, int a , int b) override{
        cout << " Product = " << calc->mul( a ,b ) << endl;
    }
    void requestDiv( Calculator* calc, int a , int b) override{
        cout << " Div  = " << calc->div( a ,b ) << endl;
    }
    
    
    
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    Calculator* calc = new BasicCalculator();
    User* user = new UserSathya();
    
    user->requestAdd( calc, 10, 20);
    user->requestSub( calc, 100, 20);
    user->requestMul( calc, 5, 20);
    user->requestSub( calc, 100, 20);
    
    return 0;
}
/*
 Hello, World!
  Sum = 30
  Sub = 80
  Product = 100
  Sub = 80
 Program ended with exit code: 0
 */
