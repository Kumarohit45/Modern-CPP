//
//  main.cpp
//  LambdaHigherOrder
//
//  Created by Sathya Babu on 08/02/24.
//

#include <iostream>
const auto less_than = [](auto x) {
  return [ x ](auto y) { std::cout << " y " << y << " x " << x << std::endl;
  return y < x;   // comp  y with the ref x now

    };
};
int main(void)
{
    auto less_than_five = less_than(5);  // set the capture first
    std::cout << " TRUE "<< less_than_five(22); // calls higherorder fun ( auto y ) now
    std::cout << less_than_five(3) << std::endl;

    std::cout << less_than_five(10) << std::endl;

    return 0;

}
