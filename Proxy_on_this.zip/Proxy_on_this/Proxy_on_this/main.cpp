//
//  main.cpp
//  Proxy_on_this
//
//  Created by Sathya Babu on 22/02/24.
//

#include <iostream>
#include <memory>

using namespace std;

// Enum for ATM states
enum class AtmState {
    IDLE,
    HAS_CARD,
    NO_CARD,
    HAS_PIN,
    NO_CASH
};

std::string CardState[ 7 ]= { "IDLE",
    "HAS_CARD",
    "NO_CARD",
    "HAS_PIN",
    "NO_CASH "};

class ATMmachine :  public enable_shared_from_this< ATMmachine >
{
    private :
    public :
    AtmState atmState ;
    double cashInTheMachine ;
    ATMmachine(): atmState(AtmState::HAS_CARD), cashInTheMachine( 5000.0) {}
    double getCashFromTheMachine(){
        return cashInTheMachine;
    }
   shared_ptr< ATMmachine > getThisPointer(){
       return shared_from_this();
    }
    
};
class GetAtmData{
    public :
    virtual AtmState getAtmState() = 0 ;
    virtual double   getCashFromTheMachine() = 0;
};
class AtmProxy : public GetAtmData{
    public :
    shared_ptr< ATMmachine > atmMachine ;
    AtmProxy(shared_ptr< ATMmachine > atmMachineTmp  ) :
             atmMachine( atmMachineTmp ){}
    AtmState getAtmState() override{
        return atmMachine->atmState ;
    }
    double getCashFromTheMachine() override {
        //  .....your logic here......

         atmMachine->cashInTheMachine -= 500;
        return atmMachine->getCashFromTheMachine();
        
    }
    
};
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Proxy for this pointer!\n";
    shared_ptr< ATMmachine> atmMachine = make_shared< ATMmachine>();
    AtmProxy atmProxy( atmMachine);
    //cout << atmMachine->getThisPointer()->cashInTheMachine << endl;
//    cout << atmMachine->getCashFromTheMachine() << endl;
    cout << atmProxy.getCashFromTheMachine() << endl;
    return 0;
}
