//
//  main.cpp
//  Variadic_fun_recurs
//
//  Created by Sathya Babu on 06/02/24.
//

#include <iostream>
#include <cassert>
using namespace std;


template <typename Func>
void call(Func f)
{
    f();
}

template <typename Func, typename... Funcs>
void call(Func f, Funcs... fs)
{
    f();
    call(fs...);
}

auto add() { std::cout << "Adding" << std::endl; }
auto sub() {std::cout << "Subtracting" << std::endl; }
auto mul() {std::cout << "Multiplying" << std::endl; }
auto divv() { std::cout << "Dividing" << std::endl; }

int main()
{
   
   
    call(add, sub, mul, divv);
    
   
   
    return 0;
}
