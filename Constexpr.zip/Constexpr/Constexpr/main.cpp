//
//  main.cpp
//  Constexpr
//
//  Created by Sathya Babu on 05/02/24.
//
/*
 Data types
 alignment
 c++ vs Asm using godbolt.org
 const vs constexpr
 Structural Binding
 changes in if and switch
 Aggregate Extension vs constructor
 initialiser List
 Null Vs nullptr
 Various castings vs any
 auto deducing
 decltype
  template inheritance, CRTP , covariant
 trailing return type
 Functional composition from ground zero creating our own STL framework vs std::bind
 type_traits nested traits
 how requires requires smells getting it right using concept requires
  inheritance of class template
  How type traits can help us with templates
 type traits vs concepts, resume
 using filter transform drop on a vector Bad and a Good approach
 Functional composition :
  std::compose, std::for_each, std::bind std::count_if,  std:: sort, std:: transform

 */
#include <iostream>
using namespace std;

const     double PI1 = 3.141592653589793;
constexpr double PI2 = 3.141592653589793;
constexpr double PI3 = PI2;

constexpr int i = 100;
int arr[ i ] ;

const int  func( const int x , const int y ){
    return x + y  ;
}

constexpr int func_constexpr( int x , int y ){
    return x * y  ;
}
//int i,j;

//int array[ func(10,20)];
int array1[ func_constexpr(10,20)];
//int array2[ func_constexpr(10,rand())];
class Test3{
    public :
    int value ;
    
    constexpr int getValue() const {
        return value ;
    }
    constexpr Test3( int value) : value( value ){}
};

template< bool UseFlag>
auto getValue(){
    if constexpr( UseFlag ){
        return 3.13;
    }else{
        return 12;
    }
}

template< typename T >
auto add(T x , T y ){
    return x + y ;
}
    
    
constexpr Test3 test( 100 );
int arr_5[ test.getValue()  ];
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, constexpr !\n";
    int val = getValue<false>(); ;
    std::cout << "int val  ! " << val << std::endl;
    double doubleVal = getValue< true>();
    std::cout << "double val  ! " << doubleVal << std::endl;
    auto result = add(10.3f,20.12f);
    std::cout << "Sum -   ! " << result  << std::endl;
    
//    int xyz ;
//    auto abc;
    
    return 0;
}











