//
//  main.cpp
//  Plugin_BT_AUX_CELL
//
//  Created by Sathya Babu on 22/02/24.
//

#include <iostream>
using namespace std;
class Connect{
    public :
    virtual ~Connect() {}
    virtual void use_BT_AUX() = 0 ;// Use interface seg principle
};
class AUX : public Connect{
    public :
    void use_BT_AUX() override{
        cout << "GOT CONNECTED WITH AUX " << endl;
    }
    
};
class BT : public Connect{
    public :
    void use_BT_AUX() override{
        cout << "GOT CONNECTED WITH BT " << endl;
    }
    
};
class Pannel {
    protected :
    shared_ptr< Connect > plugIn ;
    public :
    virtual ~Pannel() = default ;
    virtual void usePlugIn() = 0 ;
    void setConnect( shared_ptr< Connect> plug){
        plugIn = plug ;
    }
};
class CellPhone : public Pannel{
    public :
    void usePlugIn() override{
        plugIn->use_BT_AUX();
    }
};
class GoogleMaps : public Pannel{
    public :
    void usePlugIn() override{
        plugIn->use_BT_AUX();
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Connecting BT Aux to the Media Pannel!\n";
    
    auto aux = std::make_shared< AUX >();
    auto bt = std::make_shared< BT >();
    
    auto mediaPlayer = make_unique< CellPhone>();
    mediaPlayer->setConnect( aux );
    mediaPlayer->usePlugIn();
    
    auto maps = make_unique< GoogleMaps>();
    maps->setConnect( bt);
    maps->usePlugIn();
        return 0;
}
