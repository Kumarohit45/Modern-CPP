//
//  main.cpp
//  FunctionalCompo_ChkNextArg
//
//  Created by Sathya Babu on 05/02/24.
//

#include <iostream>

#include <cstdio>
#include <type_traits>
// single ton inline variable
template<typename T, typename... Ts>
constexpr inline bool are_same_v =
  std::conjunction_v<std::is_same<T, Ts>...>;

template<typename T, typename...>
struct first_arg {
  using type = T;
};

template<typename... Args>
using first_arg_t = typename first_arg<Args...>::type;

template<typename... Args>
std::enable_if_t< are_same_v<Args... >, first_arg_t<Args...>>
Add(const Args&... args) noexcept
{
  return (... + args);
   // return ( args+ ...);
}

#ifdef WILL_NOT_COMPILE
void WillNotCompile() // Use of undeclared identifier 'WillNotCompile'
{
  printf("%d\n", Add(2, 3, 4.0));
}
#endif

int main()
{
  printf("%d\n", Add(2, 3, 4));

  printf("%d\n", Add(2));
   //WillNotCompile(); // Use of undeclared identifier 'WillNotCompile'
}
// 9 2
