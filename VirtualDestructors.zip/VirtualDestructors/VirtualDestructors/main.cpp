//
//  main.cpp
//  VirtualDestructors
//
//  Created by Sathya Babu on 31/01/24.
//

#include <iostream>
using namespace std;


//    fff0
class Base{
    public :
    Base() {
        cout << " Base Ctor ... " << endl ;
    }
     
    virtual ~Base() {
        cout << " Base Dtor ... " << endl ;
    }
};
//  11ec      : fff0
class Derived : public Base{
    public :
    Derived(){
        cout << " Derived Ctor ... " << endl ;
    }
    ~Derived() {
        cout << " Derived Dtor ... " << endl ;
    }
};
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Virtual destructor!\n";
    
    // fff0          11ec
    Base* base = new Derived;
    delete  base ;   // fff0
    
    
    return 0;
}
