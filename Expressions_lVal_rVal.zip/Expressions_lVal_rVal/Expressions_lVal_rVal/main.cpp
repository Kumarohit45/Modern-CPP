//
//  main.cpp
//  Expressions_lVal_rVal
//
//  Created by Sathya Babu on 06/02/24.
//

#include <iostream>
using namespace std;

int foo(){ return 10 ; }
std::string myCat = "Percian cat";
std::string makeCat()  {
   // thread th();
    return myCat ;
}
class MyVector{
    public :
    MyVector( int i ) : size( i ){
        cout << "---> Landed at regular constructor " << endl;
        elements = new int[ i ];
        for( int j = 0 ; j < i ; j++){
            elements[ j ] = j ;
        }
    }
    ~MyVector(){
        cout << "--> Landed at Destructor " << endl ;
        delete [] elements ;
        
    }
    MyVector( const MyVector& other ) : size( other.size ){
        cout << "--> Landed at copy constructor... " << endl ;
        elements = new int[ other.size];
        
        for( int i =0 ; i<= other.size ; ++i )
        {
            elements[ i ] = other.elements[ i ];
        }
    }
    MyVector( MyVector&& other ):size(0) , elements( nullptr)
    {
        cout << "**** Landed in rValue constructor " << endl ;
        // Phase I
        elements = other.elements;
        size = other.size ;
        
        // Lets clean up the memory
        
        other.elements = nullptr ;
        other.size     = 0 ;
    }
    
    int getSize() { return size ;}
    int& operator[]( int index ){
        cout << "-->Operator[](int index )[]";
        return elements[ index ];
    }
   // private :
    int size ;
    int* elements;
};

int* begin( MyVector& v ){
    cout << " begin() " << endl;
    // return v.getSize()!=0 ? &v[ 0] : nullptr;
    return v.elements ;
}

int* end( MyVector& v ){
    cout << " end() " << endl;
     return v.getSize()!=0 ? &v[ 0] + v.getSize() : nullptr;
    
   // return v.elements + v.size ;
}
class MyClass {
    public :
    int data ;
    
    MyClass(int&& value){
        data = value ;
        cout << "Move constructor in MyCalss called " << endl;
    }
    ~MyClass() = default ;
    
};

int myFunction() { return 123 ; }

MyClass createObject() {
    cout << " Creating object " << endl;
    MyClass obj( 5 );
    return obj ; // rValue construct
}


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Expressions lValue rValue !\n";
    
    int *arr ; int *p ; int x ; int y ;
    
    // lValue
    
    int i = 10 ;
    x ;
    *p;
    arr[ 0 ];
    
    
    // Rvalue
    
    foo();
    
    12;
    x + y ;
    
    
    int& lValue = x ;
    int&& rValue = 30 ;
    
    const int& L_r_value = 23 ;  // do not get const infromt of l value
    
    nullptr_t myVar ;  // prValue
    //NULL xyz ;   // (void*)0
    
    
    std::string s("Cat");
    std::string s2( s );  // copy constructor.. // move constructor()
    std::string s3( makeCat()   );
    std::string s4( std::move( makeCat()  ) );
    
    MyVector v1( 10 );
    MyVector v2( v1 ) ;  //
    MyVector v3(  static_cast<MyVector&&>( v1 ) );
    
    for( auto x : v2 ){
        cout << x << " " ;
    }
    MyVector v4( std::move( v2 ) );
    
    for( auto x : v4 ){
        cout << x << "  X  " ;
    }
    
    int value = 1234;
    MyClass obj( value + 1 ); //  rValue
    cout << "obj.data " << obj.data << endl ;
    
    MyClass obj2( myFunction() );
    cout << "---------- createObject()   -----------" << endl ;
    MyClass obj6 = createObject()  ;
    
    MyClass obj66 ( createObject()  ) ;
    
    
    
    
    return 0;
}
