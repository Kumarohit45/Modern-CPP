//
//  main.cpp
//  Expressions_lVal_rVal
//
//  Created by Sathya Babu on 06/02/24.
//

#include <iostream>
using namespace std;
// Phase I
class Widget{
    public :
    void doWork1() & {
        cout << "working on lValue object " << endl ;
        }
    void doWork() && {
        cout << "working on rValue object " << endl ;
    }
};
// Phase II
class Widget_vec {
    public :
    using DataType = std::vector< double >;
    
    Widget_vec(){
        values = { 1.10,2.20,3.30,4.40,5.50};
    }
    
   DataType& data() &
    {
        return values ;
    }
    DataType data() &&
     {
         return std::move( values ) ;
     }
    private :
    DataType values ;
};
void setValue( int val ) {}
void setValue( const int& val ) {}  // nor its not l or r value
void setValue( int& val ) {}  // lValue
void setValue( int&& val ) {} // rVal



int foo(){ return 10 ; }
std::string myCat = "Percian cat";
std::string makeCat()  {
   // thread th();
    return myCat ;
}
class MyVector{
    public :
    MyVector( int i ) : size( i ){
        cout << "---> Landed at regular constructor " << endl;
        elements = new int[ i ];
        for( int j = 0 ; j < i ; j++){
            elements[ j ] = j ;
        }
    }
    ~MyVector(){
        cout << "--> Landed at Destructor " << endl ;
        delete [] elements ;
        
    }
    MyVector( const MyVector& other ) : size( other.size ){
        cout << "--> Landed at copy constructor... " << endl ;
        elements = new int[ other.size];
        
        for( int i =0 ; i<= other.size ; ++i )
        {
            elements[ i ] = other.elements[ i ];
        }
    }
    MyVector( MyVector&& other ):size(0) , elements( nullptr)
    {
        cout << "**** Landed in rValue constructor " << endl ;
        // Phase I
//                    elements = other.elements;
//                    size = other.size ;
//
//                    // Lets clean up the memory
//
//                    other.elements = nullptr ;
//                    other.size     = 0 ;
        
        // Phase II
        //swap( other );
        std::swap( elements, other.elements);
        std::swap( size, other.size);
    }
    
//    void swap( MyVector& other)
//    {
////                        MyVector temp ( other );
////                        other = *this ;
////                        *this = temp;
//        std::swap( elements, other.elements);
//        std::swap( size, other.size);
//    }
    
    int getSize() { return size ;}
    int& operator[]( int index ){
        cout << "-->Operator[](int index )[]";
        return elements[ index ];
    }
   // private :
    int size ;
    int* elements;
};

int* begin( MyVector& v ){
    cout << " begin() " << endl;
    // return v.getSize()!=0 ? &v[ 0] : nullptr;
    return v.elements ;
}

int* end( MyVector& v ){
    cout << " end() " << endl;
     return v.getSize()!=0 ? &v[ 0] + v.getSize() : nullptr;
    
   // return v.elements + v.size ;
}
class MyClass {
    public :
    int data ;
    
    MyClass(int&& value){
        data = value ;
        cout << "Move constructor in MyCalss called " << endl;
    }
    ~MyClass() = default ;
    
};

int myFunction() { return 123 ; }

MyClass createObject() {
    cout << " Creating object " << endl;
    MyClass obj( 5 );
    return obj ; // rValue construct
}


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Expressions lValue rValue !\n";
    
    int *arr ; int *p ; int x ; int y ;
    
    // lValue
    
    int i = 10 ;
    x ;
    *p;
    arr[ 0 ];
    
    
    // Rvalue
    
    foo();
    
    12;
    x + y ;
    
    
    int& lValue = x ;
    int&& rValue = 30 ;
    
    const int& L_r_value = 23 ;  // do not get const infromt of l value
    
    nullptr_t myVar ;  // prValue
    //NULL xyz ;   // (void*)0
    
    
    std::string s("Cat");
    std::string s2( s );  // copy constructor.. // move constructor()
    std::string s3( makeCat()   );
    std::string s4( std::move( makeCat()  ) );
    
    MyVector v1( 10 );
    MyVector v2( v1 ) ;  //
    MyVector v3(  static_cast<MyVector&&>( v1 ) );
    
    for( auto x : v2 ){
        cout << x << " " ;
    }
    MyVector v4( std::move( v2 ) );
    
    for( auto x : v4 ){
        cout << x << "  X  " ;
    }
    
    int value = 1234;
    MyClass obj( value + 1 ); //  rValue
    cout << "obj.data " << obj.data << endl ;
    
    MyClass obj2( myFunction() );
    cout << "---------- createObject()   -----------" << endl ;
    MyClass obj6 = createObject()  ;
    
    MyClass obj66 ( createObject()  ) ;
    
    // SWAP
    int a = 10 ;
    int b = 20 ;
    cout << " a " << a << endl ;
    cout << " b " << b << endl ;
    
    std::swap(a,b);
    
    cout << " a " << a << endl ;
    cout << " b " << b << endl ;
    
    
    // Phase I Widget
    
    Widget widget1 ;
    widget1.doWork1();  // returning lvalue
    
    Widget().doWork() ;  // return rValue
    
    // Phase II Widget
    Widget_vec widget;
    cout << "Display data from lValue object"<<endl;
    for( const auto& value : widget.data() )
        cout << value << " " << endl;
    
    cout << "Display data from rValue object"<<endl;
    for( const auto& value : Widget_vec().data() )
        cout << value << " " << endl;
    
    
    
    // change vector
    std::vector v={10,20,30,40,50};
    for( auto x : v )
    {
        cout << x << " " ;
    }
    
    for( auto& x : v )
    {
        x += 5 ;
        cout << x << " " ;
    }
    cout << " Changed vector "<< endl ;
    
    for( auto x : v )
    {
       
        cout << x << " " ;
    }
    
    return 0;
}
