//
//  main.cpp
//  forwarding
//
//  Created by Sathya Babu on 07/02/24.
//

#include <iostream>
using namespace std;
void funda(int&& avar){
   cout << " R - value overload called " << avar << endl;
}
void funda(int& avar){
   cout << " L - value overload called " << avar <<endl;
}
template<typename T>
T my_forward(typename std::remove_reference<T>::type& param)
{
    cout << "my_forward "<< static_cast<T>(param) << endl;   // prints 5 .. 4
    return static_cast<T>(param);  // pr value
}
template<typename T>
void call_funda(T&& parg)  // Argument universal reference..
{
    
    //funda( parg );
   // funda( std::move( parg));
//    funda( my_forward< T >(parg) ) ;
    
    funda( std::forward< T >(parg) ) ;
    
    
}
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "l avlue r value !\n";
    int myVar = 5 ;
    call_funda( myVar);  // L value overload
    call_funda( 4 );     // rvalue
    return 0;
}
