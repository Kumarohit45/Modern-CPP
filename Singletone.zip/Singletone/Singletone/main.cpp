//
//  main.cpp
//  Singletone
//
//  Created by Sathya Babu on 01/02/24.
//

#include <iostream>
using namespace std;

class Singleton{
    private :
    static  Singleton* instance ;
    static int refCounter;
    
    Singleton(){
        cout << " Singleton obj is created  " << endl ;
    }
    public :
    static Singleton  getInstance(){
        cout << " Called singleton get instance " << endl ;
        if( !instance){
            instance = new Singleton;
            
            refCounter++;
            cout << " Holding ref to the user " << refCounter << " Log." << endl;
        }
        refCounter++;
        cout << " Holding ref to the user " << refCounter << " Log." << endl;
        return *instance;
    }
    
    int getRefCounter() {
          return  refCounter;
          
      }
      int clearRefCounter() {
          cout << endl << "  user Logged out  "<< refCounter << " log. " << endl;
          
          return  refCounter--;
      }
      
      
      ~Singleton() {
          if( refCounter == 0){
              cout << endl << "  All user Logged out  DELETING THE OBJECT.. "<< refCounter << " log. " << endl;
              delete instance ;
          }
      }
      
      
    
};
Singleton* Singleton::instance = nullptr;
int Singleton::refCounter = 0 ;

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
   // Singleton* singleton = new Singleton();
    Singleton singleton1 = Singleton::getInstance();
    Singleton singleton2 = Singleton::getInstance();
    Singleton singleton3 = Singleton::getInstance();
    Singleton singleton4 = Singleton::getInstance();
    cout << " People uysing " << singleton1.getRefCounter() << endl ;
    
    
   cout << " A guy moved out of Singleton "<< singleton1.clearRefCounter()<<endl;
    
    cout << " People uysing " << singleton1.getRefCounter() << endl ;
    
    

    
    return 0;
}
