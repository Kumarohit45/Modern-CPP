//
//  main.cpp
//  SandwichBuilder
//
//  Created by Sathya Babu on 31/01/24.
//

#include <iostream>
#include<vector>
using namespace std;

class Ingredient{
    
  public:
    virtual std::string name() = 0 ;
    virtual int calories() = 0;
    virtual int cost() = 0 ;
    
};

class Bread : public Ingredient{
    public :
    
    virtual std::string name() = 0 ;
    virtual int calories() = 0;
    virtual int cost() = 0 ;
};
class Bagel : public Bread {
    public :
    std::string name() override {
        return "Bagel";
    }
    int calories() override {
        return 250 ;
    }
    int cost() override {
        return 20 ;
    }
};
class Bun : public Bread {
    public :
    std::string name() override {
        return "Bun";
    }
    int calories() override {
        return 150 ;
    }
    int cost() override {
        return 10 ;
    }
};
class Filling : public Ingredient{
    public :
    virtual std::string name() = 0 ;
    virtual int calories() = 0;
    virtual int cost() = 0 ;
    
};

class CreamCheese : public Filling {
    public :
    std::string name() override {
        return "CreamCheese";
    }
    int calories() override {
        return 350 ;
    }
    int cost() override {
        return 70 ;
    }
};

class SmokedSalmon : public Filling {
    public :
    std::string name() override {
        return "Smoked Salmon";
    }
    int calories() override {
        return 450 ;
    }
    int cost() override {
        return 170 ;
    }
};
// Lets create a class to erpresent a sandwich Builder..
class Sandwich{
    private :
    std::vector< Ingredient* > ingredients ;
    
    public :
    
    void addIngredients( Ingredient* ingredient){
        ingredients.emplace_back( ingredient);
    }
    void getSandwich(){
        for(Ingredient* i : ingredients){
            cout << i->name() << " : " << i->calories() << " Kcal "<< " cost " << i->cost() <<endl ;        }
    }
    void getCalories() {
        int totalCalories = 0 ;
        for(Ingredient* i : ingredients){
            totalCalories += i->calories();
        }
        cout << "Total calories " << totalCalories << endl ;
    }
    
};
class SandwichBuilder{
    public :
    static Sandwich readyMade() {
        Sandwich sandwich;
        sandwich.addIngredients( new Bagel() );
        sandwich.addIngredients( new SmokedSalmon() );
        sandwich.addIngredients( new CreamCheese() );
        
        return sandwich ;
    }
    static Sandwich build( Sandwich& s , Ingredient* ingredient){
        s.addIngredients( ingredient);
        return s ;
    }
};


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Sandwich builder!\n";
    Sandwich custom ;
    SandwichBuilder::build( custom ,new Bun() );
    SandwichBuilder::build( custom ,new CreamCheese() );
    cout << " Customised sandwich " << endl ;
    custom.getSandwich();
    custom.getCalories();
    
    Sandwich offTheShelf = SandwichBuilder::readyMade();
    cout << " Ready made  sandwich " << endl ;
    offTheShelf.getSandwich() ;
    offTheShelf.getCalories();
    
    
    
    
                                //    int x  = 10 ;
                                //    int y{20};
                                //    //int z{10,20,30,40};
                                //    // range for
                                //    for( int x : {11,22,33,44,55}){
                                //        cout << x << ' ';
                                //    }
    return 0;
}
