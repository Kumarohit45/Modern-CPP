//
//  main.cpp
//  ref
//
//  Created by Sathya Babu on 19/02/24.
//

#include <iostream>
#include <vector>
using namespace std;


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    int i = 10 ;
    int *p = &i ;
    cout << *p << endl;
    
    int a = 10 ;
    int b = 20 ;
    int c = 30 ;
    
//    std::vector< int* > vectPtr{ &a , &b , &c };
    std::vector< std::reference_wrapper< int > > vectPtr{ a , b ,c};
    for( auto ptr: vectPtr){
       // ( *ptr ) += 5 ;
        ptr.get() += 5 ;
    }
    for( auto ptr : vectPtr){
//        cout << ( *ptr) <<  " " << endl ;
        cout << ptr.get() <<  " " << endl ;
    }
    
    return 0;
}
