//
//  main.cpp
//  LambdaCallBack_2
//
//  Created by Sathya Babu on 08/02/24.
//

#include <iostream>
#include <algorithm>
#include <vector>
using namespace std ;

// receive lambda as funPtr(int ) = (int){ prints the value }

void ForEach( const std::vector< int >&values, void( *funPtr )( int ) ){
    
    // Turn the net on
    // Down load the data from server..
    // A service/a thread/Async thread..
    for( int value : values)
    {
        cout << " about to call lambda {}"<<endl;
        funPtr( value );
    }
    // shut the network down
}
int main(int argc, const char * argv[]) {
    std::cout << "Hello, World!\n";
    std::vector< int > values = { 1,2,3,4,5 };
    ForEach(  values , [](int value ) { cout << " Value : "<< value << endl ;}  );
    return 0;
}
