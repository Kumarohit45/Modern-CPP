//
//  main.cpp
//  LambdaCompare
//
//  Created by Sathya Babu on 08/02/24.
//


#include <iostream>
#include <string_view>
#include<array>
#include<algorithm>

using namespace std;

struct Car{
    std::string make{};
    std::string model{};
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    
    std::array<Car,3> cars{ { { "Volkswagen","Golf"},
                        {"Toyota","Corolla"},
                        {"Honda","Civic"}}};
    int comparisons{0};
    std::sort( cars.begin(),cars.end(),
              [&comparisons] (const auto&a ,const auto& b){
               ++comparisons;
        return( a.make < b.make);
    });
    cout << "Comparison compared and sorted " << comparisons + 1  << endl;
    for( const auto& car : cars ){
        cout << car.make << ' ' << car.model << endl ;
    }
    
    return 0;
}
