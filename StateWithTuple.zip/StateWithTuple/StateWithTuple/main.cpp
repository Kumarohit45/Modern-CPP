//
//  main.cpp
//  StateWithTuple
//
//  Created by Sathya Babu on 22/02/24.
//

#include <iostream>
#include <tuple>
#include <typeinfo>
using namespace std;

template<typename... States>
class StateMAchine{
    private :
    std::tuple< States...> states ;
    
    public :
    StateMAchine( States... args) : states( make_tuple( std::move( args)...)){}
    
    void displayVariousStates(){
        cout << "States... " << endl;
        displayStates< 0 >();
        cout << endl;
    }
    template< size_t Index>
    void displayStates()
    {
        if constexpr ( Index < sizeof... ( States))
        {
            cout << typeid( std::get< Index >( states)).name() << " " ;
            displayStates< Index + 1>();
        }
    }
};
struct NoCard  {} ;
struct HasCard {} ;
struct HasPin  {} ;
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "tuple states..!\n";
    NoCard noCard   ;
    HasCard hasCard ;
    HasPin hasPin   ;
    StateMAchine< NoCard, HasCard, HasPin> sm (noCard,hasCard,hasPin);
    sm.displayVariousStates();
    return 0;
}
