//
//  main.cpp
//  MandateWhileDriving
//
//  Created by Sathya Babu on 06/02/24.
//
/*
 
 Mandats of a class while testing..
 adding a Pump to it..
 variadic expressions
 function recur...
 fold expressions
 
 expressions lValue rvalue xValue prValue
 perfect forwarding
 
 
 stuructural bindings
 Aggregate
 Initilizer list vs constructors
 
 
 
 */

#include <iostream>
using namespace std;

template< typename  T>
concept MandateWhileDriving = requires( T t ){
    { t.accelerator() };
    { t.applyBreak() };
    { t.fuel };
    
    requires std::is_same_v< decltype( t.fuel),float>;
   // requires std::convertible_to< decltype(t.fuel),float>;
   // requires ( t.fuel >= 10 );
};

class Engine {
public:
//    
    
    void accelerator() {
        std::cout << "Pump the accelerator.." << std::endl;
    }
    void applyBreak() {
        std::cout << "Apply the brakes.." << std::endl;
    }
    //  so its not declared at concept MandateWhileDriving = requires
    void notRelatedToEngine(){
        std::cout << "This fun not related to engine.." << std::endl;
    }
    float fuel = 20.0f;
};
class Car {
    
    public :
    template<MandateWhileDriving T>
    void drive( T arg){
        
        arg.accelerator();
        arg.applyBreak();
        arg.notRelatedToEngine();
    }
};


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    Car myCar ;
    Engine engine ;
    myCar.drive( engine );
    return 0;
}
