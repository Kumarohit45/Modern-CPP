//
//  main.cpp
//  Lambda_Variadic_Fold
//
//  Created by Sathya Babu on 07/02/24.
//

#include <iostream>
using namespace std;

void print(){}

template<typename First, typename... Rest >
void print( const First& first , const Rest... args)
{
    cout << first << endl ;
    print(args...);
}
template<typename ...T>
auto doSomething(T... t ){
    return ( t +...);
 }
// Phase II
constexpr auto add = [] <class... T > ( T ...args)
{
    return (args +...);
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
//    std::function<void<Args...> varadic_lambda = []  (auto... parm ) {  print(parm...);    };
    auto  varadic_lambda = []  (auto... parm ) {  print(parm...);    };
    varadic_lambda(1,"LOL",23,"KPIT");
    
    print(123,"Cool",12,"Samsung");
    cout << " Do Something fold " << doSomething(1,2,3,4,5) << endl;
    cout << " Do Something fold lambda  " << add(10,20,30,40,50) << endl;
    return 0;
}
