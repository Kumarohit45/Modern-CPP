//
//  main.cpp
//  Variadic_template
//
//  Created by Sathya Babu on 06/02/24.
//

#include <iostream>
using namespace std;

template< typename T >
void print( const T& t ){
    cout << " In me " <<  t << endl ;
}
template< typename First , typename... Rest>
void print( const First& first, const Rest&... rest)
{
    //std::cout << __PRETTY_FUNCTION__ << endl;
    cout << first << " , " ;
    print( rest...);
}

//  Phase II Fold expression
template<typename... T>
auto AddRecur( T ...t){
    return ( t +...);
}


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    print("First",1,"Second",2,"Third",3);
    
    cout << " Sum from Fold expression " << AddRecur(1,2,3,4,5.55,6,7,8,9,10);
    return 0;
}


/*
infix expression ( 5 + 3 ) * ( 8 - 2 ) = 48
postfix expression  5 3 + 8 2 - *  valus is 48

stack

5
3
    + calc( 5 , 3 , + ) = 8
8
2
  -   calc( 8 ,2 , -)  = 6
  *   calc( 8 ,6 , *)  = 48

 

 "First",1,"Second",2,"Third",3
 first           rest
 "First"        1, "Second",2,"Third",3
 1
 "Second"         "Third",3
 2                  ,3
 
 "Third"             3
 3
 
 Hello, World!
 void print(const First &, const Rest &...) [First = char[6], Rest = <int, char[7], int, char[6], int>]
 First , void print(const First &, const Rest &...) [First = int, Rest = <char[7], int, char[6], int>]
 1 , void print(const First &, const Rest &...) [First = char[7], Rest = <int, char[6], int>]
 Second , void print(const First &, const Rest &...) [First = int, Rest = <char[6], int>]
 2 , void print(const First &, const Rest &...) [First = char[6], Rest = <int>]
 Third ,  In me 3
 Program ended with exit code: 0
 
 
 */
