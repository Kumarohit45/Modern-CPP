//
//  main.cpp
//  Step_2
//
//  Created by Sathya Babu on 08/02/24.
//

#include <iostream>
#include <vector>
#include <variant>
using namespace std;
using var_t = std::variant<int,const char*>;

struct PrintInt{
    void operator()( int i ){
        cout << i << endl ;
    }
   
};
struct PrintString{
    void operator()( const char* str ){
        cout << str << endl ;
    }
};

struct Print : PrintInt, PrintString{
    using PrintInt::operator();
    using PrintString::operator();
    
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Lambda OverLoad !\n";
    std::vector<var_t> vars = { 1,2,"Hello World"};
   
    for( auto& v : vars)
    {
        std::visit( Print{}, v );
    }
    return 0;
}
