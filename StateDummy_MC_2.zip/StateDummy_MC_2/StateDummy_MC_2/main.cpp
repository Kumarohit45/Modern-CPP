//
//  main.cpp
//  StateDummy_MC_2
//
//  Created by Sathya Babu on 13/02/24.
//

#include <iostream>
#include<variant>
#include <functional>
using namespace std;
class Machine{
    public :
    void on() { cout << "Machine is turned on.." << endl;}
    void off() { cout << "Machine is turned off.." << endl;}
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    using MachineFSM = variant<
                                std::function< void( Machine& ) >,
                                std::function<void()>
                             >;
    MachineFSM machinePTR[] = {
        []( Machine& m){ m.off(); },
        []( Machine& m){ m.on(); }
        
    };
    Machine fsm ;
    int yourOption;
    cout << " 0  / 1 :  " ;
    cin >> yourOption ;
    
    std::visit(
               [ yourOption , &fsm ](auto& func ){
                   
                   if constexpr ( std::is_invocable_v< decltype( func), Machine&>){
                       if( yourOption == 0  || yourOption == 1 )
                           func( fsm ); // []( Machine& m ) fsm = m
                       else
                           cout << " Invalid option " << endl ;
                   }else {
                       cout << " Invalid function type " << endl ;
                   }
                   
               } ,machinePTR[ yourOption ]
            );
    
    return 0;
}
