//
//  main.cpp
//  Step_6
//
//  Created by Sathya Babu on 08/02/24.

//

use visit and variants

Assume the visitor is your auditor and that you have a loan for both your automobile and your home.
Allow the auditor to visit you, gather necessary data, and compute your loan for the month.


#include <iostream>
#include <vector>
#include <variant>
using namespace std;
using var_t = std::variant<int,const char*>;
//
//template<class... Ts>
//struct Print : Ts...{
//    using Ts::operator()...;
//    
//};
//template<typename... Ts>
//auto MakePrint( Ts... ts){
//    return Print<Ts...>{ ts...};
//}

// Phase II
template<class... Ts> struct overload : Ts... { using Ts::operator()...; };
template<class... Ts> overload(Ts...) -> overload<Ts...>;



int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Lambda OverLoad !\n";
    std::vector<var_t> vars = { 1,2,"Hello World"};
   
    
    
    for( auto& v : vars)
    {
        std::visit(
                   overload{
                       
                       [] ( int i ){ cout << i << endl ;},
                       [] ( const char* str ){ cout << str << endl ;}
                   },v);
    }
//
//    for( auto& v : vars)
//    {
//        std::visit(
//               MakePrint(
//                         
//                           [] ( int i ){ cout << i << endl ;},
//                           [] ( const char* str ){ cout << str << endl ;}
//                          ),v);
//    }
    return 0;
}
