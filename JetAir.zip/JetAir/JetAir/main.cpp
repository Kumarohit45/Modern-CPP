//
//  main.cpp
//  JetAir
//
//  Created by Sathya Babu on 31/01/24.
//

#include <iostream>
using namespace std;
/*
 How to think and implement....
 1. Create a interface iFlighStatus for communication
 acrosss class
 2. Create a jetAir which will reg and communicate with
 users
 3. Create a customer class You Me and others
 4. Lets have a vector to store the user credentials
 in JetAir
 
 class iFlightstatus{
 public :
 virtual void flightOnTime()=0;
 virtual void flightDelayed()=0;
 
 };
 std::vector< iFlightstatus > users
 
 users.emplace_back( prathima );
 users.emplace_back( Suresh );
 users.emplace_back( Virupaksh );
 
 5. When ever the state of JetAir changes ( Pilot on leave)
     0/1
 6. notifyUsers
 
  notifyUsers(){
      for( user: users ){
               user->flightDelayed();
               suresh->flightDelayed();
               virupaksh->flightDelayed();
       }
 
 
 */



class iFlightstatus{
public :
    virtual void FlightOnTime()=0;
    virtual void FlightDelayed()=0;

};
class JetAir{
    public :
    std::vector< class iFlightstatus* > users ;
    
    void register_(iFlightstatus* iFlightUser )
    {
        users.emplace_back( iFlightUser );
        
    }
    
    int getUSers(){
        return users.size();
    }
    void unRegister_( iFlightstatus* iFlightUser){
        
        auto it = std::find(users.begin(),users.end(),iFlightUser);
        if( it != users.end() ){
            users.erase( it );
        }
    }
             // Got triggred from the extrnal class..
    void setState( int state ){
        notify( state );
    }
    void notify(int state ){
        if( state ){
            for( auto cUser: users ){
                cUser->FlightOnTime();
            }
        }else {
            for( int i = 0 ; i < users.size() ; i++){
                users[  i ] -> FlightDelayed();
            }
        }
    }
    
    
};



class Suresh :   public  iFlightstatus  {
    public :
    Suresh(){
        cout <<" Suresh obj created.." << endl;
        
    }
    
    void FlightOnTime() override{
        cout <<" Flight On time." << endl;
    }
    
    void FlightDelayed() override {
        cout <<" Flight Delayed." << endl;
    }
    
};

class Arun :   public  iFlightstatus  {
    public :
    Arun(){
        cout <<" Arun obj created.." << endl;
        
    }
    //register_( this );
    
    void FlightOnTime()  override{
        cout <<" Flight On time." << endl;
    }
    
    void FlightDelayed() override{
        cout <<" Flight Delayed." << endl;
    }
    };

class Virupaksh :  public iFlightstatus  {
    public :
    Virupaksh(){
        cout <<" Virupaksh  obj created.." << endl;
        
    }
    void FlightOnTime() override{
        cout <<" Flight On time." << endl;
    }
    
    void FlightDelayed() override {
        cout <<" Flight Delayed." << endl;
    }
    
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Welcome to Jet Air!\n";
    JetAir jetAir ;
    Arun  arun ;
    Suresh suresh;
    Virupaksh virupaksh;
    jetAir.register_( &arun );
    jetAir.register_( &suresh );
    jetAir.register_( &virupaksh );
    
    jetAir.setState( 0 ); // Pilot
    cout << " People on flight " << jetAir.getUSers() << endl ;
    jetAir.unRegister_( &arun );
    cout << " People on flight " << jetAir.getUSers() << endl ;
    
    return 0;
}
/*
 Welcome to Jet Air!
  Arun obj created..
  Suresh obj created..
  Virupaksh  obj created..
  Flight Delayed.
  Flight Delayed.
  Flight Delayed.
  People on flight 3
  People on flight 2
 Program ended with exit code: 0
 */
