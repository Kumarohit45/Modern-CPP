//
//  main.cpp
//  Lambda_Global
//
//  Created by Sathya Babu on 08/02/24.
//

#include <iostream>
using namespace std;

int global = 10 ;
auto testSpeedString = [] ( int speed ) -> std::string{ if( speed > 100)
    return "You'r a super fast driver " ; else return "A Compsed driver ";};
    

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    cout << global << endl;
    auto foo = [ = ] ()mutable noexcept{ ++global;};
    foo();
    cout << global << endl;
    const auto increaseGlobal = []() noexcept{ ++global ;};
    increaseGlobal();
    cout << global << endl;
    // Phase II
    auto str = testSpeedString( 90 );
    cout << str ;
    
    return 0;
}
