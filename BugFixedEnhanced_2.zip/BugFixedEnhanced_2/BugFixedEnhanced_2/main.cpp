//
//  main.cpp
//  BugFixedEnhanced_2
//
//  Created by Sathya Babu on 05/02/24.
//
#include <iostream>
#include <type_traits>

    template<typename T1, typename T2>
    static auto add(const T1& a, const T2& b) {
        return a + b;
    }


// Define the is_variable trait
template<typename T>
struct is_variable : std::is_object<T> {};

// Define the ResultOfCalculation concept
template<typename FN, typename T1, typename T2>
concept ResultOfCalculation = requires(const FN& op, const T1& x, const T2& y) {
    std::is_invocable_v<FN, T1, T2> && std::is_same_v<decltype(op(x, y)), decltype(op(x, y))>;
    // Add additional requirements as needed
};

// Define the resultOfCalculation_template_triats_Invoke_variable function template
template<typename FN, typename T1, typename T2>
requires ResultOfCalculation<FN, T1, T2> && is_variable<T1>::value && is_variable<T2>::value
decltype(auto) resultOfCalculation_5(const FN& op, const T1& x, const T2& y) {
    return op(x, y);
}

int main() {
    int x = 10;
    int y = 20;
    std::cout << "Result: " << resultOfCalculation_5(add<int, int>, x, y) << std::endl;
    return 0;
}
