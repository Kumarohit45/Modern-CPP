//
//  main.cpp
//  BrewTeaCoffee
//
//  Created by Sathya Babu on 29/01/24.
//

#include <iostream>
using namespace std;

class Brew{
    public :
    void BoilWatter(){
        cout << "Boil watter" << endl;
    }
    void BoilMilk(){
        cout << "Boil Milk" << endl;
    }
    void pourItInMug(){
        cout << "Pour it in mug" << endl;
    }
    virtual void AddCondiments1() = 0 ;
    virtual void AddCondiments2() = 0 ;
    virtual void AddCondiments3() = 0 ;
    
    void execute(){
        
        BoilWatter();
        BoilMilk();
        AddCondiments1();
        AddCondiments2();
        pourItInMug();
        
    }
    
};

class Tea : public Brew {
    public :
    
    void AddCondiments1() override {
        cout << "Steep the tea bag.." << endl;
    }
    void AddCondiments2() override {
        cout << "Add Lime.." << endl;
    }
    void AddCondiments3() override {
        cout << "Add Sugar.." << endl;
    }
    
};

class Coffee : public Brew {
    public :
    
    void AddCondiments1() override {
        cout << "Grinded Fresh Coffee Bean.." << endl;
    }
    void AddCondiments2() override {
        cout << "Add Cinnamon.." << endl;
    }
    void AddCondiments3() override {
        cout << "Add Sugar.." << endl;
    }
    
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Using pure virtual functions!\n";
    Brew* brew = new Tea();
//    brew->BoilMilk();
//    brew->AddCondiments2();
//    brew->pourItInMug();
//    brew->AddCondiments3();
//    brew->AddCondiments1();
   // brew->execute();
    
    Brew* array[] { new Tea(), new Coffee() };
    
    for(int i = 0 ; i < 2 ; i++){
        array[ i ]->execute();
    }
    
    
    
    return 0;
}
