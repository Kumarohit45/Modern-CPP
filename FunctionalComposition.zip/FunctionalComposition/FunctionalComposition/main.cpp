//
//  main.cpp
//  FunctionalComposition
//
//  Created by Sathya Babu on 05/02/24.
//

#include <iostream>
#include<type_traits>

using namespace std;

const std::string message = "I'm here";
const std::string& foo(){
    return  message;
}


auto& increment( int& a )
{
    a++ ; 
    return a ;
}
struct A { double x ; };
const A* a ;

decltype( a->x ) y ;
decltype( a->x ) z = y ;


constexpr auto f( float x ) -> decltype(x + 23.12)
{
    return x + 23.12;
}

int ff( float x ) { return x + 23.12; }
auto ghetData() -> int ( & )[ 2 ]
{
    
    int arr[] = { 10,20 };
    return arr ;
}

constexpr auto add( const int a, const int b ) -> int
{
    return  a + b ;
}
//(*)();
// Place holder or Callback.
int (*MyFnPtr)( int x , int y ) = add ;

constexpr auto  resultOfCalculation( int ( *OP )(int,int),
                        int x , int y) -> decltype(( *OP )( x , y ) )
{
    return ( *OP )( x , y );
}

template<typename FN , typename T1, typename T2>
constexpr auto  resultOfCalculation_2(
                                      const FN& OP ,
                                      const T1 x ,
                                      const T2 y
                                          ) -> decltype( OP( x ,y ))
{
    
    return OP( x,y);
}

template< typename T >
struct is_variable : std::is_object< T > {};

template<typename FN , typename T1, typename T2>
constexpr auto  resultOfCalculation_3(
                                      const FN& OP ,
                                      const T1 x ,
                                      const T2 y
                                          ) -> std::enable_if_t<
                                           std::is_invocable_v< FN,T1,T2> &&
                                           is_variable< T1 >::value &&
                                           is_variable< T2 >::value,

                                           decltype( OP( x ,y ))
                                          >
{
    
    return OP( x,y);    // Invokable
}
template<typename... Args>
auto add2( Args... args ) -> int{
    return ( args +...);   // i += k ;
   // return (  ...+ args);
}

template<typename FN , typename... Args>
constexpr auto  resultOfCalculation_4(
                                      const FN& OP ,
                                      Args... args
                                    ) -> decltype( OP( args... ))
{
    
    return OP( args...);
}
//compose( add,mul,sub,div , 12,32 );

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "auto decltype type triats functional composition !\n";
    
    int a = 100 ;
    auto& y = increment( a );
    cout <<" a " << a << " y " << y << endl;
    const auto f1 = foo();
    decltype( foo() ) f2 = foo();
    decltype( auto ) f3 = foo();
    cout << f1 << endl;
    cout << f2 << endl;
    cout << f3 << endl;
 
    int store[ 6 ] ={ 10,20,30,40,50};
    
    
    //   10      =  __ __ __ __ __ __  __
    //              10 12 14 16 18 20  21
    
    cout << *(store + 2 ) << endl ;
    cout << " Legacy way of calling. SUM of fnptr = "<< MyFnPtr(12,22) << endl ;
    cout << " Functional composition = "<<
    resultOfCalculation( add,100, 200) << endl ;
    int xx = 123 ;
    int* p = &xx ;
    cout << " Templ Functional composition 2 = "<<
    resultOfCalculation_2( add,300, 200) << endl ;
    cout << " Templ Functional composition 3 = "<<
    resultOfCalculation_3( add,100, 222) << endl ;
    
    cout << " Templ Functional composition 4 = "<<
    resultOfCalculation_4( add2<int,int,int,int,int>,100, 222,300.23,400,500) << endl ;
    
    // Thoufgh it works case is failed...
    
    // (*)() function pointers ---> OUTDATED....
    
    using namespace std::placeholders;
    std::function< int( int ) > std_fun = std::bind(&add,123, _1);
    int summ = std_fun(111);
    cout << " Result from bind " << summ << endl ;
    return 0;
}
