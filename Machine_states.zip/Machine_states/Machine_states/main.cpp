//
//  main.cpp
//  Machine_states
//
//  Created by Sathya Babu on 22/02/24.
//

#include <iostream>
using namespace  std;
template<typename State>
struct TransactionTo{
    template<typename Machine>
    void execute( Machine& machine){
        
        machine.template transactionTo< State >();
    }
};
struct machine {
    template< typename  State>
    void transactionTo(){
        cout << " In transaction with state  : " << typeid( State ).name() << endl ;
    }
};
struct MyState {};
struct YourState {};
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "MAchine state...!\n";
    machine machine ;
    TransactionTo< YourState > transaction ;
    transaction.execute( machine );
    return 0;
}
