//
//  main.cpp
//  MUtex_2
//
//  Created by Sathya Babu on 19/02/24.
//
#include <iostream>
#include <vector>
#include <thread>
using namespace std;
//std::mutex mutex;
template< typename Func, typename Iterator>
void executeThreads( Func&& func, Iterator begin, Iterator end ){
    std::vector< std::thread > threads;
    for(auto it = begin ; it != end ; it++){
        
        std::lock_guard< std::mutex > lock( mutex );
        std::this_thread::sleep_for(std::chrono::seconds( 3 )) ;; // block for 3 sec.
        threads.emplace_back( std::forward<Func>( func), std::ref( *it ));

    }
    for( auto& thread: threads){
        cout << thread.get_id() << endl;
        thread.join();
    }
    
}
void processEngineIOT( int& value ){
    // Base ca=lass Engine can be a Engine manager which can deal with the functions( getState, setState, so on .. or it can be state machine
    std::string iot[ 5 ] ={ "Oil Filter IOT ","Petrol IOT","Piston","Cumbersion ","Coolent "};
    cout << "\t State Started : " <<  endl;
    
            cout << "\t State Processiing : " <<  endl;
    
    cout << "IOT processed : " << iot[ value ]<< endl ;
    cout << "\t State Proc completed : " <<  endl;
}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "mutex \n";
    std::vector< int > values ={ 1,2,3,4,5};
    executeThreads( processEngineIOT,values.begin(),values.end());
    std::vector< std::thread > thread2;
//    std::thread tt1 ( processValue,100 );
//    std::thread tt2 ( processValue,200 );
//    tt1.join();
//    tt2.join();
    
    return 0;
}
