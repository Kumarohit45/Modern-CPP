//
//  main.cpp
//  Integral
//
//  Created by Sathya Babu on 05/02/24.
//

#include <iostream>

#include <cstdio>
#include <type_traits>

// Concept :  powerful mechanism for expressing and enforcing type requirements in template code

// Phase I
//
template <typename T>
concept Integral = std::is_integral<T>::value;
Integral auto gcd( Integral auto a , Integral auto b ) { if( b==0 ) return a ;
else return gcd( b, a % b );
}
// Phase II

template <typename T>
concept is_Integral = std::is_integral<T>::value;
template< is_Integral T    >
T gcd( T a , T b){
    if( b ==0 ){
        return a ;
    }else return gcd( b, a % b );
       
}
template< typename T >
concept Addable = requires( T a , T b ){
    
    { a + b }  -> std::same_as< T >;
};
template< Addable T >
T addTwoValues( T a , T b ) {
    return a + b ;
}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << " gcd of 10 and 20 " << gcd( 10,20 ) << std::endl ;;
    std::cout << addTwoValues(5,7.12) << std::endl;
    return 0;
}
