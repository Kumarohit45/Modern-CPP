//
//  main.cpp
//  Lambda_functionObject
//
//  Created by Sathya Babu on 07/02/24.
//

#include <iostream>
using namespace std;

class Annoymous{
    public :
    
    template<typename T1, typename T2>
    constexpr auto operator  ()( const  T1 a , const T2 b  ){
        return a + b ;
    }
    
};

template<typename T ,auto T1>
auto add(){
    
}

constexpr auto sum = [](const auto& a, const auto& b){ return a + b; };

int main(int argc, const char * argv[]) {
    
 
    
    // insert code here...
    std::cout << "FunctionObject - Lambda \n";
    Annoymous an ;
    cout << " Returned from function object " << an(10,20) << endl;
    cout << " Returned from Lambda " << sum(100,200) << endl;
    return 0;
}
