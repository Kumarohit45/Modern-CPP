//
//  main.cpp
//  Weak_ptr
//
//  Created by Sathya Babu on 15/02/24.
//
/*

Because shared_ptr objects count as an owner, this function locks the owned pointer,
preventing it from being released (for at least as long as the returned object does not releases it).
This operation is executed atomically.
*/
#include <iostream>
#include <memory>
 
std::weak_ptr<int> gw;
 
void observe()
{
    std::cout << "gw.use_count() == " << gw.use_count() << "; "; //  gw.use_count() == 1;
    // we have to make a copy of shared pointer before usage:
    if (std::shared_ptr<int> spt = gw.lock()) {                 // when gw dosent percist its false!
        std::cout << "*spt == " << *spt << '\n';                 // *spt == 42
    }
    else {
        std::cout << "gw is expired\n";
    }
}

int main()
{
    {
        auto sp = std::make_shared<int>(42);
        gw = sp;
 
        observe();
    }
 
      observe();
   
       
}
/*
 gw.use_count() == 1; *spt == 42
 gw.use_count() == 0; gw is expired
 Program ended with exit code: 0
 */
