//
//  main.cpp
//  StateDummy_1
//
//  Created by Sathya Babu on 13/02/24.
//

#include <iostream>
using namespace std;
class Machine {
    public :
    void on(){ cout << " Machine is turned on. " << endl; }
    void off(){ cout << " Machine is turned off. " << endl; }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "!am state Dummy \n";
    void( Machine ::*machinePTR[] )() = {
        &Machine::off , &Machine::on
    };
    Machine fsm ;
    int yourOption ;
    cout << " 0/1 " << endl;
    cin >> yourOption;
    ( fsm.*machinePTR[ yourOption ])();
    return 0;
}
