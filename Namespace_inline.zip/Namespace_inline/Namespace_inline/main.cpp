//
//  main.cpp
//  Namespace_inline
//
//  Created by Sathya Babu on 22/02/24.
//

#include <iostream>
using namespace std;
namespace  Wifi_App_Versioning {

    namespace  version_1 {
        void transmitPAcket(){
            cout << " Transmiting Via xyz protocall ver 1" << endl;
        }
    }

  namespace  version_2 {
        void transmitPAcket(){
            cout << " Transmiting Via xyz protocall ver 2 depricated.." << endl;
        }
    }

inline    namespace  version_3 {
      [[ deprecated( "use transmitPacket() version 2 ")]]
           void transmitPAcket(){
               cout << " Transmiting Via xyz protocall ver 3" << endl;
           }
          void transmitPAcketviaVOIP(){
              cout << " Transmiting Via VOIP  protocall ver 3 " << endl;
          }
}


}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    int i=0;
    Wifi_App_Versioning::version_1::transmitPAcket();
    Wifi_App_Versioning::transmitPAcket();
    Wifi_App_Versioning::version_3::transmitPAcket();
    return 0;
}
/*
EngineManager
     .SubscribeOn( BackGroundScheduler)
     .ensureAllIOTisOK()
     .observeOn( DashBoardSchedulear);
*/
