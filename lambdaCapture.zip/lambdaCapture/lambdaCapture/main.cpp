//
//  main.cpp
//  lambdaCapture
//
//  Created by Sathya Babu on 07/02/24.
//

#include <iostream>
using namespace std;

int main(int argc, const char * argv[]) {
    // insert code here...
    const auto print =[]( const char* str, int x , int y){
        cout << str << " : "  << x << " " << y << endl;
    };
    int x = 1 , y =1 ;
    print("In main...",x,y);

    auto foo =[ x , y, &print ]() mutable {
        ++ x ;
        ++ y ;
        print("In foo()",x,y);
    };
    foo();
    print("In main ",x,y);
    return 0;
}
