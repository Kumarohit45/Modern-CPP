//
//  main.cpp
//  Varint_visit
//
//  Created by Sathya Babu on 08/02/24.
//

#include <iostream>
#include <variant>
#include <vector>
#include <typeinfo>
using namespace std;
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << '\n';

      std::vector<std::variant<char, long, float, int, double, long long>>      // 1
                 vecVariant = {5, '2', 5.4, 100ll, 2011l, 3.5f, 2017};
    for(auto& v :vecVariant){
        // std::visit( lambda , v );
        //          visitable , visitor
        std::visit([]( auto arg ){ cout << arg <<" ";}, v );
        std::visit([]( auto arg ){ cout << typeid(arg).name() <<" ";}, v );
    }
    return 0;
}
