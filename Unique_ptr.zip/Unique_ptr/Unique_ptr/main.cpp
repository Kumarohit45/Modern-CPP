//
//  main.cpp
//  Unique_ptr
//
//  Created by Sathya Babu on 14/02/24.
//

#include <iostream>
using namespace std;
#include <memory>

struct Foo {
         Foo() { std::cout << "Foo::Foo" << std::endl; }
        ~Foo() { std::cout << "Foo::~Foo" << std::endl; }

    void foo() { std::cout << "Foo::foo() func called..." << std::endl; }
};
void f(const Foo &) {
    std::cout << "f(const Foo&)" << std::endl;
}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::unique_ptr< Foo > p1( std::make_unique< Foo>() );
   // std::unique_ptr< Foo > p1( new Foo );
   // std::unique_ptr< Foo > p2 = p1 ;
//    if( p1 ) p1->foo();
    std::unique_ptr< Foo > p2 ( std::move( p1 )  );
    p1 = nullptr ;
    if( p1 ) p1->foo();
    std::cout << "Hello, World!\n";
    return 0;
}
