//
//  main.cpp
//  ObserveEngineRXWay_1
//
//  Created by Sathya Babu on 22/02/24.
//

#include <iostream>
#include <memory>
#include <vector>
#include <map>
#include <mutex>


class Observer {
public:
    virtual void onDataChanged(const std::string& sensorName, int newValue) = 0;
};


class EngineManager {
private:
    std::map<std::string, int> sensorData; // Map to store sensor data
    std::vector<std::shared_ptr<Observer>> observers;
    std::mutex mutex;
    bool engineRunning; // Flag to indicate engine running state

public:
    EngineManager() : engineRunning(false) {}

    void addObserver(const std::shared_ptr<Observer>& observer) {
        observers.push_back(observer);
    }

    void startEngine() {
        std::lock_guard<std::mutex> lock(mutex);
        engineRunning = true;
        std::cout << "Engine started." << std::endl;
    }

    void stopEngine() {
        std::lock_guard<std::mutex> lock(mutex);
        engineRunning = false;
        std::cout << "Engine stopped." << std::endl;
    }

    //  Receive data from sensors and notify observers if data changes
    void onDataReceived(const std::string& sensorName, int newValue) {
        std::lock_guard<std::mutex> lock(mutex);
        if (sensorData[sensorName] != newValue) { // Check if data has changed
            sensorData[sensorName] = newValue; // Update sensor data
            notifyObservers(sensorName, newValue);
        }
    }

private:
    void notifyObservers(const std::string& sensorName, int newValue) {
        for (const auto& observer : observers) {
            observer->onDataChanged(sensorName, newValue);
        }
    }
};


class Dashboard : public Observer {
public:
   
    void onDataChanged(const std::string& sensorName, int newValue) override {
        std::cout << "Dashboard received updated data from sensor '" << sensorName << "': " << newValue << std::endl;
    }
};


class Sensor {
private:
    EngineManager& engineManager;
    std::string name;

public:
    Sensor(const std::string& sensorName, EngineManager& manager) : name(sensorName), engineManager(manager) {}

    void sendData(int value) {
        std::cout << "Sensor '" << name << "' sending data: " << value << std::endl;
        engineManager.onDataReceived(name, value);
    }
};

class PetrolTank {
private:
    int petrolLevel;
    EngineManager& engineManager;

public:
    PetrolTank(EngineManager& manager) : petrolLevel(100), engineManager(manager) {}

    int getPetrolLevel() const {
        return petrolLevel;
    }

    void consumePetrol() {
        petrolLevel -= 10;
        if (petrolLevel <= 10) {
            engineManager.onDataReceived("Petrol", petrolLevel); // Notify EngineManager when petrol level is low
        }
    }
};


class Car {
public:
    EngineManager engineManager;
    PetrolTank petrolTank;

    Car() : petrolTank(engineManager) {
        engineManager.addObserver(std::make_shared<Dashboard>());
    }

    Car& startEngine() {
        engineManager.startEngine();
        return *this;
    }

    Car& rpmSensor(int value) {
        Sensor rpmSensor("RPM", engineManager);
        rpmSensor.sendData(value);
        return *this;
    }

    Car& tempSensor(int value) {
        Sensor tempSensor("Temperature", engineManager);
        tempSensor.sendData(value);
        return *this;
    }

    Car& checkPetrolLevel() {
        petrolTank.consumePetrol();
        return *this;
    }
};

int main() {
    Car car;
    car.startEngine()
       .rpmSensor(20)
       .tempSensor(90)
       .checkPetrolLevel();

    return 0;
}
/*
 Engine started.
 Sensor 'RPM' sending data: 20
 Dashboard received updated data from sensor 'RPM': 20
 Sensor 'Temperature' sending data: 90
 Dashboard received updated data from sensor 'Temperature': 90
 Program ended with exit code: 0
 */
