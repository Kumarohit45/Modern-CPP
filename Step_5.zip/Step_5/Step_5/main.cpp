//
//  main.cpp
//  Step_5
//
//  Created by Sathya Babu on 08/02/24.
//
//
//  main.cpp
//  Step_4
//
//  Created by Sathya Babu on 08/02/24.
//
//
//  main.cpp
//  Step_3
//
//  Created by Sathya Babu on 08/02/24.
//

#include <iostream>
#include <vector>
#include <variant>
using namespace std;
using var_t = std::variant<int,const char*>;

template<class... Ts>
struct Print : Ts...{
    using Ts::operator()...;
    
};


template<typename... Ts>
auto MakePrint( Ts... ts){
    return Print<Ts...>{ ts...};
}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Lambda OverLoad !\n";
    std::vector<var_t> vars = { 1,2,"Hello World"};
   
    
    for( auto& v : vars)
    {
        std::visit(
               MakePrint(
                         
                           [] ( int i ){ cout << i << endl ;},
                           [] ( const char* str ){ cout << str << endl ;}
                          ),v);
    }
    return 0;
}
