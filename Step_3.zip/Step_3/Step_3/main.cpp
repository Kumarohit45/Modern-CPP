//
//  main.cpp
//  Step_3
//
//  Created by Sathya Babu on 08/02/24.
//

#include <iostream>
#include <vector>
#include <variant>
using namespace std;
using var_t = std::variant<int,const char*>;

struct PrintInt{
    void operator()( int i ){
        cout << i << endl ;
    }
   
};
struct PrintString{
    void operator()( const char* str ){
        cout << str << endl ;
    }
};
/*
 
 struct Print : PrintInt, PrintCString { // (3)
     using PrintInt::operator();
     using PrintCString::operator();
 };
 */
template<class... Ts>
struct Print : Ts...{
    using Ts::operator()...;
    
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Lambda OverLoad !\n";
    std::vector<var_t> vars = { 1,2,"Hello World"};
   
    for( auto& v : vars)
    {
        std::visit( Print<PrintString,PrintInt>{}, v );
    }
    return 0;
}
