//
//  main.cpp
//  THread_CallBack
//
//  Created by Sathya Babu on 19/02/24.
//

#include <iostream>
#include <thread>
#include <vector>
#include <future>
#include <functional>
using namespace std ;

enum class ThreadState {
    Running,
    Completed,
    Errored
};

void run_with_callback( const std::function< void( ThreadState)>& callback){
    std::thread t( [ callback ] () {
        
        try{
            std::this_thread::sleep_for( std::chrono::seconds( 2 ));
            callback( ThreadState::Completed);
        }catch(...){
            callback( ThreadState::Errored);
        }
       
    });
    // Report task is running
    callback(ThreadState::Running);
    
    t.join();
}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    std::vector< std::future< ThreadState>> futures ;
    
    auto callBack = []( ThreadState state ){
        switch( state ){
            case  ThreadState::Running :
                cout << " Thread is running " << endl ;
                break;
            case  ThreadState::Completed :
                cout << " Thread completed successfully.. " << endl ;
                break;
            case  ThreadState::Errored :
                cout << " Error encountered in Thread " << endl ;
                break;
        }
    };
    
    for( int i =0 ; i < 5  ; ++i ){
        decltype( auto ) f = std::async( std::launch::async,run_with_callback,callBack);
    }
    
    for( auto& f : futures ){
        auto state = f.get();
        callBack( state );
    }
    return 0;
}
