//
//  main.cpp
//  Lambda_HigherOrderFunctions
//
//  Created by Sathya Babu on 07/02/24.
//

#include <iostream>
using namespace std;


auto makeMeAdeveloper(const std::string& name )
{   int id = 123 ;
    int age = 43 ;
    // &
    // &,age,id
    return [ = ]( ){
        cout << " I'm a developer, my name is " << name << "Age is "<< age << endl;
    };
}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    
 
    auto sayName{ makeMeAdeveloper("Sathya..") };
    sayName();
    
    return 0;
}
