//
//  main.cpp
//  Menu_KFC_combo
//
//  Created by Sathya Babu on 01/02/24.
//

#include <iostream>
#include<vector>
using namespace std;

class interfaceComponent{
    public :
    char* getName() { return name ;}
    virtual void ls() = 0 ;
protected:
    char name[ 30 ];
    static int indent ;
};
int interfaceComponent::indent = 0 ;

class Leaf : public  interfaceComponent
{
    public :
    Leaf( char* n)
    {
        strcpy(name,n );
    }
    void ls()
    {
        for(int i = 0 ; i < indent;i++)
        {
            cout << ' ';
           
        }
        cout << name << endl ;
    }
};
class Composite:public interfaceComponent
{
protected:
    std::vector<interfaceComponent*> files;
    public :
    
    Composite( char* n)
    {
        strcpy( name,n);
    }
    void ls(){
        
        for( int i = 0 ; i < indent ;i++)
        {
            cout << ' ';
        }
       // cout << files.size() << " Composit found under ( " << name <<" ) " << endl;
        cout << "name  : " << endl;
        indent += 5 ;
        
        for( int i = 0 ; i < files.size() ;i++){
           // cout << "Getting the file name : " << endl;
            files[ i ]->ls();
            
        }
        indent -= 5 ;
    }
    
    void display()
    {
        cout << name << " All child :  "<< endl ;
        for( int i = 0 ; files.size() ;i++)
        {
            for( int j = 0 ; j<3 ;j++)
                cout << ' ';
                cout << files[ i ]->getName() << endl ;
        }
       
    
    }
};
class Menu : public Composite
{
    public :
    Menu( char* s ) : Composite( s ) {}
    
    void Add( interfaceComponent* f ){
        files.emplace_back( f );
    }
    void AddComp( char* s ){
        Add( new Composite( s ));
    }
    void AddLeaf( char* s ){
        Add( new Leaf( s ));
    }
    
    Menu* GetHandle( char* s ){
        for( int i = 0 ; i< files.size(); i++){
            if( strcmp(s,files[ i ]->getName() ) == 0 )
                return ( Menu*) files[ i ];
        }
        cout << "Directory " << s << "not found in " << name << endl ;
        exit( 1 );
    }
    void remove( char* s ){
        std::vector< interfaceComponent*>::iterator p = files.begin();
        // points to the first elemt of the vector.
        for( int i = 0 ; i< files.size() ; i++, p++)
        {
            if( strcmp( s, files[ i ]->getName())== 0)
                files.erase( p );
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Composeing a Menu...!\n";
    
    Menu m("Menu");     // First the main menu is created.
        
        m.AddComp("File"); // One composite object is inserted into the main menu.
        m.AddLeaf("Edit"); // One leaf object is inserted.
        m.AddLeaf("Search");// One leaf object is inserted.

        m.GetHandle("File")->AddLeaf("New");
        m.GetHandle("File")->AddLeaf("Open");
        m.GetHandle("File")->AddComp("Run");
        m.GetHandle("File")->GetHandle("Run")->AddLeaf("compile");
        m.GetHandle("File")->GetHandle("Run")->AddLeaf("build");
        m.GetHandle("File")->remove("Open");
    
    Composite* mgetHandle = m.GetHandle("File");
    mgetHandle->ls();
    
    
    m.AddComp("Combo"); // 500
   
    m.GetHandle("Combo")->AddComp("Burger"); // 510
    
//
//    m.GetHandle("Combo")->GetLeftHandle("Burger")->AddLeaf("Bun");
//    m.GetHandle("Combo")->GetRightHandle("Burger")->AddLeaf("Bun");
    
    m.GetHandle("Combo")->GetHandle("Burger")->AddLeaf("Bun"); // 511
    m.GetHandle("Combo")->GetHandle("Burger")->AddLeaf("Chicken"); // 512
    m.GetHandle("Combo")->GetHandle("Burger")->AddLeaf("Onion"); // 513
   
    // WATCH the traversal here..
    // If we have to use  inOrder postOrder preOrder traversal of the tree
    // NOTE Add such traversal to Composite
    Composite *mGetHandle =  m.GetHandle("Combo");
    mGetHandle->ls();
   
    
//    m.GetHandle("Combo")->AddLeaf("Bun");
//    m.GetHandle("Combo")->AddLeaf("Chicken");
//    m.GetHandle("Combo")->AddLeaf("Cheese");
    
    m.GetHandle("Combo")->AddComp("Coke");
    
    m.GetHandle("Combo")->GetHandle("Coke")->AddLeaf("250ml");
    
    m.GetHandle("Combo")->AddComp("Nuggets");
    m.GetHandle("Combo")->GetHandle("Nuggets")->AddLeaf("Medium");
    m.GetHandle("Combo")->AddLeaf("Take away Box");
  
    m.ls(); // displays all the children of object m with their hierarchies.
    
    return 0;
}
