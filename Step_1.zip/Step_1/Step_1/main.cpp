//
//  main.cpp
//  Step_1
//
//  Created by Sathya Babu on 08/02/24.
//

#include <iostream>
#include <vector>
#include <variant>
using namespace std;
using var_t = std::variant<int,const char*>;

struct Print{
    void operator()( int i ){
        cout << i << endl ;
    }
    void operator()( const char* str ){
        cout << str << endl ;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Lambda OverLoad !\n";
    std::vector<var_t> vars = { 1,2,"Hello World"};
    Print p;
    for( auto& v : vars)
    {
        std::visit( Print{}, v );
    }
    return 0;
}
