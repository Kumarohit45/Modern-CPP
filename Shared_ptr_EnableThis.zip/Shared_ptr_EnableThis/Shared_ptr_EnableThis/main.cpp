//
//  main.cpp
//  Shared_ptr_EnableThis
//
//  Created by Sathya Babu on 15/02/24.
//

#include <iostream>
#include <memory>
// Phase II
class MyClass2{
    public :
    void printFromMyCalss2(){
        std::cout << "Hello I'm in MyClass2 !! " << std::endl ;
        
    }
};
class MyClass : public std::enable_shared_from_this< MyClass>{
private:
    int var = 123 ;
    MyClass2 myClass2 ;
    public :
            // Phase II
           
    
    std::shared_ptr< MyClass> getShared(){
       // return(*this );
        return shared_from_this();
    }
    void print(){
        std::cout << "Hello I'm in MyClass!! " << std::endl ;
        
    }
  void  getmyVarAndObject(){
       var = 567 ;
      std::cout << " getmyVarAndObject " << var << std::endl;
       myClass2.printFromMyCalss2();
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Enable shared ptr...!\n";
    
    std::shared_ptr< MyClass > obj = std::make_shared< MyClass >();
    std::shared_ptr< MyClass > sharedObject = obj->getShared();
    sharedObject->print();
    // Phase II
    //sharedObject->myClass2.printFromMyCalss2();
    sharedObject->getmyVarAndObject();
    return 0;
}
